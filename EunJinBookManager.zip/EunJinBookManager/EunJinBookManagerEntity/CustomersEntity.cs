﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EunJinBookManagerEntity
{
    public class CustomersEntity
    {
        public int c_id { get; set; }
        public string c_nm { get; set; }
        public string addr { get; set; }
        public string phone { get; set; }
    }
}