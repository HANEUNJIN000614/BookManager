﻿namespace EunJinBookManager
{
    partial class Customers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Customers));
            this.eghisTablePanel1 = new eGhis.Controls.EghisTablePanel();
            this.BtnClose = new eGhis.Controls.EghisButton();
            this.BtnDelete = new eGhis.Controls.EghisButton();
            this.BtnSave = new eGhis.Controls.EghisButton();
            this.BtnReset = new eGhis.Controls.EghisButton();
            this.GridSearch = new eGhis.Controls.EghisDataGrid();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridView2 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.eghisGroupBox1 = new eGhis.Controls.EghisGroupBox();
            this.eghisLayoutControl1 = new eGhis.Controls.EghisLayoutControl();
            this.eghisTablePanel2 = new eGhis.Controls.EghisTablePanel();
            this.eghisLabel1 = new eGhis.Controls.EghisLabel();
            this.M = new eGhis.Controls.EghisRadioButton();
            this.F = new eGhis.Controls.EghisRadioButton();
            this.eghisComboBox1 = new eGhis.Controls.EghisComboBox();
            this.eghisTextBox4 = new eGhis.Controls.EghisTextBox();
            this.eghisTextBox3 = new eGhis.Controls.EghisTextBox();
            this.eghisTextBox2 = new eGhis.Controls.EghisTextBox();
            this.TxtCId = new eGhis.Controls.EghisTextBox();
            this.Root = new eGhis.Controls.EghisLayoutGroup();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem7 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem8 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            ((System.ComponentModel.ISupportInitialize)(this.eghisTablePanel1)).BeginInit();
            this.eghisTablePanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridSearch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eghisGroupBox1)).BeginInit();
            this.eghisGroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.eghisLayoutControl1)).BeginInit();
            this.eghisLayoutControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.eghisTablePanel2)).BeginInit();
            this.eghisTablePanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.M.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.F.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eghisComboBox1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eghisTextBox4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eghisTextBox3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eghisTextBox2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtCId.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Root)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            this.SuspendLayout();
            // 
            // eghisTablePanel1
            // 
            this.eghisTablePanel1.AutoFontSizeChange = true;
            this.eghisTablePanel1.CellBorder = eGhis.Controls.CellBorderStyle.None;
            this.eghisTablePanel1.Columns.AddRange(new DevExpress.Utils.Layout.TablePanelColumn[] {
            new DevExpress.Utils.Layout.TablePanelColumn(DevExpress.Utils.Layout.TablePanelEntityStyle.Relative, 1F),
            new DevExpress.Utils.Layout.TablePanelColumn(DevExpress.Utils.Layout.TablePanelEntityStyle.Relative, 1F),
            new DevExpress.Utils.Layout.TablePanelColumn(DevExpress.Utils.Layout.TablePanelEntityStyle.Relative, 1F),
            new DevExpress.Utils.Layout.TablePanelColumn(DevExpress.Utils.Layout.TablePanelEntityStyle.Relative, 1F)});
            this.eghisTablePanel1.ContentImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.eghisTablePanel1.Controls.Add(this.BtnClose);
            this.eghisTablePanel1.Controls.Add(this.BtnDelete);
            this.eghisTablePanel1.Controls.Add(this.BtnSave);
            this.eghisTablePanel1.Controls.Add(this.BtnReset);
            this.eghisTablePanel1.Location = new System.Drawing.Point(337, 10);
            this.eghisTablePanel1.Name = "eghisTablePanel1";
            this.eghisTablePanel1.Rows.AddRange(new DevExpress.Utils.Layout.TablePanelRow[] {
            new DevExpress.Utils.Layout.TablePanelRow(DevExpress.Utils.Layout.TablePanelEntityStyle.Absolute, 26F)});
            this.eghisTablePanel1.Size = new System.Drawing.Size(258, 82);
            this.eghisTablePanel1.TabIndex = 3;
            // 
            // BtnClose
            // 
            this.BtnClose._IconType = eGhis.Controls.IconType.None;
            this.BtnClose.AutoFontSizeChange = true;
            this.BtnClose.ButtonActionPosition = eGhis.Controls.ButtonActionPosition.Left;
            this.BtnClose.ButtonActionType = eGhis.Controls.ButtonActionType.None;
            this.eghisTablePanel1.SetColumn(this.BtnClose, 3);
            this.BtnClose.ImageOptions.Location = DevExpress.XtraEditors.ImageLocation.TopCenter;
            this.BtnClose.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("BtnClose.ImageOptions.SvgImage")));
            this.BtnClose.ImageSize = new System.Drawing.Size(0, 0);
            this.BtnClose.Location = new System.Drawing.Point(195, 11);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.PreFixedButtonSize = eGhis.Controls.PreFixedWidth.None;
            this.eghisTablePanel1.SetRow(this.BtnClose, 0);
            this.BtnClose.Size = new System.Drawing.Size(63, 59);
            this.BtnClose.TabIndex = 3;
            this.BtnClose.Text = "닫기";
            // 
            // BtnDelete
            // 
            this.BtnDelete._IconType = eGhis.Controls.IconType.None;
            this.BtnDelete.AutoFontSizeChange = true;
            this.BtnDelete.ButtonActionPosition = eGhis.Controls.ButtonActionPosition.Left;
            this.BtnDelete.ButtonActionType = eGhis.Controls.ButtonActionType.None;
            this.eghisTablePanel1.SetColumn(this.BtnDelete, 2);
            this.BtnDelete.ImageOptions.Location = DevExpress.XtraEditors.ImageLocation.TopCenter;
            this.BtnDelete.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("BtnDelete.ImageOptions.SvgImage")));
            this.BtnDelete.ImageSize = new System.Drawing.Size(0, 0);
            this.BtnDelete.Location = new System.Drawing.Point(130, 11);
            this.BtnDelete.Name = "BtnDelete";
            this.BtnDelete.PreFixedButtonSize = eGhis.Controls.PreFixedWidth.None;
            this.eghisTablePanel1.SetRow(this.BtnDelete, 0);
            this.BtnDelete.Size = new System.Drawing.Size(63, 59);
            this.BtnDelete.TabIndex = 2;
            this.BtnDelete.Text = "삭제";
            // 
            // BtnSave
            // 
            this.BtnSave._IconType = eGhis.Controls.IconType.None;
            this.BtnSave.AutoFontSizeChange = true;
            this.BtnSave.ButtonActionPosition = eGhis.Controls.ButtonActionPosition.Left;
            this.BtnSave.ButtonActionType = eGhis.Controls.ButtonActionType.None;
            this.eghisTablePanel1.SetColumn(this.BtnSave, 1);
            this.BtnSave.ImageOptions.Location = DevExpress.XtraEditors.ImageLocation.TopCenter;
            this.BtnSave.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("BtnSave.ImageOptions.SvgImage")));
            this.BtnSave.ImageSize = new System.Drawing.Size(0, 0);
            this.BtnSave.Location = new System.Drawing.Point(66, 11);
            this.BtnSave.Name = "BtnSave";
            this.BtnSave.PreFixedButtonSize = eGhis.Controls.PreFixedWidth.None;
            this.eghisTablePanel1.SetRow(this.BtnSave, 0);
            this.BtnSave.Size = new System.Drawing.Size(63, 59);
            this.BtnSave.TabIndex = 1;
            this.BtnSave.Text = "저장";
            // 
            // BtnReset
            // 
            this.BtnReset._IconType = eGhis.Controls.IconType.None;
            this.BtnReset.AutoFontSizeChange = true;
            this.BtnReset.ButtonActionPosition = eGhis.Controls.ButtonActionPosition.Left;
            this.BtnReset.ButtonActionType = eGhis.Controls.ButtonActionType.None;
            this.eghisTablePanel1.SetColumn(this.BtnReset, 0);
            this.BtnReset.ImageOptions.Location = DevExpress.XtraEditors.ImageLocation.TopCenter;
            this.BtnReset.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("BtnReset.ImageOptions.SvgImage")));
            this.BtnReset.ImageSize = new System.Drawing.Size(0, 0);
            this.BtnReset.Location = new System.Drawing.Point(1, 11);
            this.BtnReset.Name = "BtnReset";
            this.BtnReset.PreFixedButtonSize = eGhis.Controls.PreFixedWidth.None;
            this.eghisTablePanel1.SetRow(this.BtnReset, 0);
            this.BtnReset.Size = new System.Drawing.Size(63, 59);
            this.BtnReset.TabIndex = 0;
            this.BtnReset.Text = "초기화";
            // 
            // GridSearch
            // 
            this.GridSearch.AutoFontSizeChange = true;
            this.GridSearch.AutoSaveLoadLayout = false;
            this.GridSearch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.GridSearch.GridRowFont = new System.Drawing.Font("Tahoma", 9F);
            this.GridSearch.GridRowHeaderFont = new System.Drawing.Font("Tahoma", 9F);
            this.GridSearch.GridSelectionType = eGhis.Controls.GridSelectionType.Row;
            this.GridSearch.GroupPanelText = " 항목을 끌어 그룹을 설정할 수 있습니다.";
            this.GridSearch.Location = new System.Drawing.Point(2, 23);
            this.GridSearch.MainView = this.gridView1;
            this.GridSearch.Name = "GridSearch";
            this.GridSearch.NewRowType = eGhis.Controls.NewRowType.None;
            this.GridSearch.ShowColumnHeader = true;
            this.GridSearch.ShowGroupingPanel = false;
            this.GridSearch.Size = new System.Drawing.Size(594, 180);
            this.GridSearch.TabIndex = 0;
            this.GridSearch.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1,
            this.gridView2});
            // 
            // gridView1
            // 
            this.gridView1.GridControl = this.GridSearch;
            this.gridView1.GroupPanelText = " 항목을 끌어 그룹을 설정할 수 있습니다.";
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsCustomization.AllowGroup = false;
            this.gridView1.OptionsCustomization.AllowQuickHideColumns = false;
            this.gridView1.OptionsMenu.ShowAutoFilterRowItem = false;
            this.gridView1.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView1.OptionsView.ShowGroupPanel = false;
            // 
            // gridView2
            // 
            this.gridView2.GridControl = this.GridSearch;
            this.gridView2.GroupPanelText = " 항목을 끌어 그룹을 설정할 수 있습니다.";
            this.gridView2.Name = "gridView2";
            this.gridView2.OptionsCustomization.AllowGroup = false;
            this.gridView2.OptionsCustomization.AllowQuickHideColumns = false;
            this.gridView2.OptionsMenu.ShowAutoFilterRowItem = false;
            this.gridView2.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView2.OptionsView.ShowGroupPanel = false;
            // 
            // eghisGroupBox1
            // 
            this.eghisGroupBox1.AutoFontSizeChange = true;
            this.eghisGroupBox1.Controls.Add(this.GridSearch);
            this.eghisGroupBox1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.eghisGroupBox1.Location = new System.Drawing.Point(0, 313);
            this.eghisGroupBox1.Margin = new System.Windows.Forms.Padding(5);
            this.eghisGroupBox1.Name = "eghisGroupBox1";
            this.eghisGroupBox1.Size = new System.Drawing.Size(598, 205);
            this.eghisGroupBox1.TabIndex = 1;
            this.eghisGroupBox1.Text = "고객 조회";
            // 
            // eghisLayoutControl1
            // 
            this.eghisLayoutControl1.AutoFontSizeChange = true;
            this.eghisLayoutControl1.Controls.Add(this.eghisTablePanel2);
            this.eghisLayoutControl1.Controls.Add(this.eghisComboBox1);
            this.eghisLayoutControl1.Controls.Add(this.eghisTextBox4);
            this.eghisLayoutControl1.Controls.Add(this.eghisTextBox3);
            this.eghisLayoutControl1.Controls.Add(this.eghisTextBox2);
            this.eghisLayoutControl1.Controls.Add(this.TxtCId);
            this.eghisLayoutControl1.Location = new System.Drawing.Point(12, 160);
            this.eghisLayoutControl1.Name = "eghisLayoutControl1";
            this.eghisLayoutControl1.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(716, 14, 650, 870);
            this.eghisLayoutControl1.Root = this.Root;
            this.eghisLayoutControl1.Size = new System.Drawing.Size(341, 145);
            this.eghisLayoutControl1.TabIndex = 4;
            this.eghisLayoutControl1.Text = "eghisLayoutControl1";
            // 
            // eghisTablePanel2
            // 
            this.eghisTablePanel2.AutoFontSizeChange = true;
            this.eghisTablePanel2.CellBorder = eGhis.Controls.CellBorderStyle.None;
            this.eghisTablePanel2.Columns.AddRange(new DevExpress.Utils.Layout.TablePanelColumn[] {
            new DevExpress.Utils.Layout.TablePanelColumn(DevExpress.Utils.Layout.TablePanelEntityStyle.Relative, 1F),
            new DevExpress.Utils.Layout.TablePanelColumn(DevExpress.Utils.Layout.TablePanelEntityStyle.Relative, 1F),
            new DevExpress.Utils.Layout.TablePanelColumn(DevExpress.Utils.Layout.TablePanelEntityStyle.Relative, 1F)});
            this.eghisTablePanel2.Controls.Add(this.M);
            this.eghisTablePanel2.Controls.Add(this.F);
            this.eghisTablePanel2.Controls.Add(this.eghisLabel1);
            this.eghisTablePanel2.Location = new System.Drawing.Point(172, 12);
            this.eghisTablePanel2.Name = "eghisTablePanel2";
            this.eghisTablePanel2.Rows.AddRange(new DevExpress.Utils.Layout.TablePanelRow[] {
            new DevExpress.Utils.Layout.TablePanelRow(DevExpress.Utils.Layout.TablePanelEntityStyle.Absolute, 26F)});
            this.eghisTablePanel2.Size = new System.Drawing.Size(157, 20);
            this.eghisTablePanel2.TabIndex = 5;
            // 
            // eghisLabel1
            // 
            this.eghisTablePanel2.SetColumn(this.eghisLabel1, 0);
            this.eghisLabel1.Location = new System.Drawing.Point(1, 3);
            this.eghisLabel1.Name = "eghisLabel1";
            this.eghisTablePanel2.SetRow(this.eghisLabel1, 0);
            this.eghisLabel1.Size = new System.Drawing.Size(50, 14);
            this.eghisLabel1.TabIndex = 9;
            this.eghisLabel1.Text = "성별 (sex)";
            // 
            // M
            // 
            this.M.AutoFontSizeChange = true;
            this.M.CheckBoxStyle = DevExpress.XtraEditors.Controls.CheckBoxStyle.Radio;
            this.M.CheckedColor = System.Drawing.Color.Empty;
            this.eghisTablePanel2.SetColumn(this.M, 1);
            this.M.Location = new System.Drawing.Point(53, 1);
            this.M.Name = "M";
            this.M.Properties.Caption = "남";
            this.M.Properties.CheckBoxOptions.Style = DevExpress.XtraEditors.Controls.CheckBoxStyle.Radio;
            this.M.Properties.RadioGroupIndex = 1;
            this.M.RadioGroupIndex = 1;
            this.eghisTablePanel2.SetRow(this.M, 0);
            this.M.Size = new System.Drawing.Size(50, 20);
            this.M.TabIndex = 8;
            this.M.TabStop = false;
            this.M.UnCheckedColor = System.Drawing.Color.Empty;
            // 
            // F
            // 
            this.F.AutoFontSizeChange = true;
            this.F.CheckBoxStyle = DevExpress.XtraEditors.Controls.CheckBoxStyle.Radio;
            this.F.CheckedColor = System.Drawing.Color.Empty;
            this.eghisTablePanel2.SetColumn(this.F, 2);
            this.F.Location = new System.Drawing.Point(106, 1);
            this.F.Name = "F";
            this.F.Properties.Caption = "여";
            this.F.Properties.CheckBoxOptions.Style = DevExpress.XtraEditors.Controls.CheckBoxStyle.Radio;
            this.F.Properties.RadioGroupIndex = 1;
            this.F.RadioGroupIndex = 1;
            this.eghisTablePanel2.SetRow(this.F, 0);
            this.F.Size = new System.Drawing.Size(50, 20);
            this.F.TabIndex = 7;
            this.F.TabStop = false;
            this.F.UnCheckedColor = System.Drawing.Color.Empty;
            // 
            // eghisComboBox1
            // 
            this.eghisComboBox1.AutoFontSizeChange = true;
            this.eghisComboBox1.DropDownStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            this.eghisComboBox1.Location = new System.Drawing.Point(107, 84);
            this.eghisComboBox1.Name = "eghisComboBox1";
            this.eghisComboBox1.PopupSizeable = DevExpress.XtraEditors.Controls.BestFitMode.None;
            this.eghisComboBox1.Properties.AllowMouseWheel = false;
            this.eghisComboBox1.Properties.AutoHeight = false;
            this.eghisComboBox1.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.eghisComboBox1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.eghisComboBox1.Properties.NullText = " ";
            this.eghisComboBox1.Properties.ShowHeader = false;
            this.eghisComboBox1.SetEmptyText = " ";
            this.eghisComboBox1.ShowHeader = false;
            this.eghisComboBox1.Size = new System.Drawing.Size(222, 25);
            this.eghisComboBox1.StyleController = this.eghisLayoutControl1;
            this.eghisComboBox1.TabIndex = 11;
            // 
            // eghisTextBox4
            // 
            this.eghisTextBox4.AutoFillHeight = true;
            this.eghisTextBox4.AutoFontSizeChange = true;
            this.eghisTextBox4.BorderStyle = eGhis.Controls.CustomBorderStyle.SingleBorder;
            this.eghisTextBox4.CharacterCasingType = System.Windows.Forms.CharacterCasing.Normal;
            this.eghisTextBox4.EmptyHintText = "";
            this.eghisTextBox4.Location = new System.Drawing.Point(107, 113);
            this.eghisTextBox4.Name = "eghisTextBox4";
            this.eghisTextBox4.PasswordChar = '\0';
            this.eghisTextBox4.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.eghisTextBox4.Properties.MaskSettings.Set("mask", "(\\d+-?)*");
            this.eghisTextBox4.Properties.MaskSettings.Set("showPlaceholders", false);
            this.eghisTextBox4.Properties.MaskSettings.Set("MaskManagerType", typeof(DevExpress.Data.Mask.RegExpMaskManager));
            this.eghisTextBox4.ReadonlyType = false;
            this.eghisTextBox4.Size = new System.Drawing.Size(222, 20);
            this.eghisTextBox4.StyleController = this.eghisLayoutControl1;
            this.eghisTextBox4.TabIndex = 10;
            this.eghisTextBox4.TextInputType = eGhis.Controls.TextInputType.Default;
            this.eghisTextBox4.TextMaskType = eGhis.Controls.TextMaskType.Phone;
            this.eghisTextBox4.UseNumericSeparator = false;
            // 
            // eghisTextBox3
            // 
            this.eghisTextBox3.AutoFillHeight = true;
            this.eghisTextBox3.AutoFontSizeChange = true;
            this.eghisTextBox3.BorderStyle = eGhis.Controls.CustomBorderStyle.SingleBorder;
            this.eghisTextBox3.CharacterCasingType = System.Windows.Forms.CharacterCasing.Normal;
            this.eghisTextBox3.EmptyHintText = "";
            this.eghisTextBox3.Location = new System.Drawing.Point(107, 36);
            this.eghisTextBox3.Name = "eghisTextBox3";
            this.eghisTextBox3.PasswordChar = '\0';
            this.eghisTextBox3.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.eghisTextBox3.ReadonlyType = false;
            this.eghisTextBox3.Size = new System.Drawing.Size(222, 20);
            this.eghisTextBox3.StyleController = this.eghisLayoutControl1;
            this.eghisTextBox3.TabIndex = 6;
            this.eghisTextBox3.TextInputType = eGhis.Controls.TextInputType.Default;
            this.eghisTextBox3.TextMaskType = eGhis.Controls.TextMaskType.None;
            this.eghisTextBox3.UseNumericSeparator = false;
            // 
            // eghisTextBox2
            // 
            this.eghisTextBox2.AutoFillHeight = true;
            this.eghisTextBox2.AutoFontSizeChange = true;
            this.eghisTextBox2.BorderStyle = eGhis.Controls.CustomBorderStyle.SingleBorder;
            this.eghisTextBox2.CharacterCasingType = System.Windows.Forms.CharacterCasing.Normal;
            this.eghisTextBox2.EmptyHintText = "";
            this.eghisTextBox2.Location = new System.Drawing.Point(107, 60);
            this.eghisTextBox2.Name = "eghisTextBox2";
            this.eghisTextBox2.PasswordChar = '\0';
            this.eghisTextBox2.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.eghisTextBox2.ReadonlyType = false;
            this.eghisTextBox2.Size = new System.Drawing.Size(222, 20);
            this.eghisTextBox2.StyleController = this.eghisLayoutControl1;
            this.eghisTextBox2.TabIndex = 5;
            this.eghisTextBox2.TextInputType = eGhis.Controls.TextInputType.Default;
            this.eghisTextBox2.TextMaskType = eGhis.Controls.TextMaskType.None;
            this.eghisTextBox2.UseNumericSeparator = false;
            // 
            // TxtCId
            // 
            this.TxtCId.AutoFillHeight = true;
            this.TxtCId.AutoFontSizeChange = true;
            this.TxtCId.BorderStyle = eGhis.Controls.CustomBorderStyle.SingleBorder;
            this.TxtCId.CharacterCasingType = System.Windows.Forms.CharacterCasing.Normal;
            this.TxtCId.EmptyHintText = "";
            this.TxtCId.Location = new System.Drawing.Point(107, 12);
            this.TxtCId.Name = "TxtCId";
            this.TxtCId.PasswordChar = '\0';
            this.TxtCId.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.TxtCId.ReadonlyType = false;
            this.TxtCId.Size = new System.Drawing.Size(61, 20);
            this.TxtCId.StyleController = this.eghisLayoutControl1;
            this.TxtCId.TabIndex = 4;
            this.TxtCId.TextInputType = eGhis.Controls.TextInputType.Default;
            this.TxtCId.TextMaskType = eGhis.Controls.TextMaskType.None;
            this.TxtCId.UseNumericSeparator = false;
            // 
            // Root
            // 
            this.Root.AppearanceItemCaption.Options.UseTextOptions = true;
            this.Root.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.Root.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.Root.GroupBordersVisible = false;
            this.Root.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem1,
            this.layoutControlItem2,
            this.layoutControlItem7,
            this.layoutControlItem8,
            this.layoutControlItem3,
            this.layoutControlItem4});
            this.Root.Name = "Root";
            this.Root.Size = new System.Drawing.Size(341, 145);
            this.Root.TextVisible = false;
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.ContentHorzAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.layoutControlItem1.ContentVertAlignment = DevExpress.Utils.VertAlignment.Center;
            this.layoutControlItem1.Control = this.TxtCId;
            this.layoutControlItem1.CustomizationFormText = "고객ID (c_id)";
            this.layoutControlItem1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(160, 24);
            this.layoutControlItem1.Text = "고객ID (c_id)";
            this.layoutControlItem1.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.layoutControlItem1.TextSize = new System.Drawing.Size(90, 14);
            this.layoutControlItem1.TextToControlDistance = 5;
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.ContentHorzAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.layoutControlItem2.ContentVertAlignment = DevExpress.Utils.VertAlignment.Center;
            this.layoutControlItem2.Control = this.eghisTextBox2;
            this.layoutControlItem2.CustomizationFormText = "c_nam";
            this.layoutControlItem2.Location = new System.Drawing.Point(0, 48);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Size = new System.Drawing.Size(321, 24);
            this.layoutControlItem2.Text = "주소 (addr)";
            this.layoutControlItem2.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.layoutControlItem2.TextSize = new System.Drawing.Size(90, 14);
            this.layoutControlItem2.TextToControlDistance = 5;
            // 
            // layoutControlItem7
            // 
            this.layoutControlItem7.ContentHorzAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.layoutControlItem7.ContentVertAlignment = DevExpress.Utils.VertAlignment.Center;
            this.layoutControlItem7.Control = this.eghisTextBox4;
            this.layoutControlItem7.Location = new System.Drawing.Point(0, 101);
            this.layoutControlItem7.Name = "layoutControlItem7";
            this.layoutControlItem7.Size = new System.Drawing.Size(321, 24);
            this.layoutControlItem7.Text = "전화번호 (phone)";
            this.layoutControlItem7.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.layoutControlItem7.TextSize = new System.Drawing.Size(90, 14);
            this.layoutControlItem7.TextToControlDistance = 5;
            // 
            // layoutControlItem8
            // 
            this.layoutControlItem8.ContentHorzAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.layoutControlItem8.ContentVertAlignment = DevExpress.Utils.VertAlignment.Center;
            this.layoutControlItem8.Control = this.eghisComboBox1;
            this.layoutControlItem8.Location = new System.Drawing.Point(0, 72);
            this.layoutControlItem8.MinSize = new System.Drawing.Size(155, 24);
            this.layoutControlItem8.Name = "layoutControlItem8";
            this.layoutControlItem8.Size = new System.Drawing.Size(321, 29);
            this.layoutControlItem8.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem8.Text = "직업 (job)";
            this.layoutControlItem8.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.layoutControlItem8.TextSize = new System.Drawing.Size(90, 14);
            this.layoutControlItem8.TextToControlDistance = 5;
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.ContentHorzAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.layoutControlItem3.ContentVertAlignment = DevExpress.Utils.VertAlignment.Center;
            this.layoutControlItem3.Control = this.eghisTextBox3;
            this.layoutControlItem3.Location = new System.Drawing.Point(0, 24);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Size = new System.Drawing.Size(321, 24);
            this.layoutControlItem3.Text = "고객명 (c_nm)";
            this.layoutControlItem3.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.layoutControlItem3.TextSize = new System.Drawing.Size(90, 14);
            this.layoutControlItem3.TextToControlDistance = 5;
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.Control = this.eghisTablePanel2;
            this.layoutControlItem4.Location = new System.Drawing.Point(160, 0);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Size = new System.Drawing.Size(161, 24);
            this.layoutControlItem4.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem4.TextVisible = false;
            // 
            // Customers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(598, 518);
            this.Controls.Add(this.eghisLayoutControl1);
            this.Controls.Add(this.eghisTablePanel1);
            this.Controls.Add(this.eghisGroupBox1);
            this.Name = "Customers";
            this.Text = "도서관리시스템 > 고객관리";
            ((System.ComponentModel.ISupportInitialize)(this.eghisTablePanel1)).EndInit();
            this.eghisTablePanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.GridSearch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eghisGroupBox1)).EndInit();
            this.eghisGroupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.eghisLayoutControl1)).EndInit();
            this.eghisLayoutControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.eghisTablePanel2)).EndInit();
            this.eghisTablePanel2.ResumeLayout(false);
            this.eghisTablePanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.M.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.F.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eghisComboBox1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eghisTextBox4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eghisTextBox3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eghisTextBox2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtCId.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Root)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private eGhis.Controls.EghisTablePanel eghisTablePanel1;
        private eGhis.Controls.EghisButton BtnClose;
        private eGhis.Controls.EghisButton BtnDelete;
        private eGhis.Controls.EghisButton BtnSave;
        private eGhis.Controls.EghisButton BtnReset;
        private eGhis.Controls.EghisDataGrid GridSearch;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView2;
        private eGhis.Controls.EghisGroupBox eghisGroupBox1;
        private eGhis.Controls.EghisLayoutControl eghisLayoutControl1;
        private eGhis.Controls.EghisRadioButton M;
        private eGhis.Controls.EghisRadioButton F;
        private eGhis.Controls.EghisTextBox eghisTextBox3;
        private eGhis.Controls.EghisTextBox eghisTextBox2;
        private eGhis.Controls.EghisTextBox TxtCId;
        private eGhis.Controls.EghisLayoutGroup Root;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private eGhis.Controls.EghisComboBox eghisComboBox1;
        private eGhis.Controls.EghisTextBox eghisTextBox4;
        private eGhis.Controls.EghisLabel eghisLabel1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem7;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem8;
        private eGhis.Controls.EghisTablePanel eghisTablePanel2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
    }
}